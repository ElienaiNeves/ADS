-- criar banco de dados
--create DATABASE teste

--criar tabela
create table usuario(id int identity(1,1),
login varchar(30) primary key,
senha varchar(255),
nome varchar(50),
cep char(10)
)

---select na tabela-----
select * from usuario

---incluir dados em qualquer tabela ERRADO!--
insert into usuario values('jose','123','elienai','321')

---incluir dados em qualquer tabela Certo!--

insert into usuario (
login,
senha,
nome) values('carla','123','carla')

--alter table usuario add endereco varchar(100)


--- alterar registro------------
update usuario set cep = '111' , senha='000'
where id =5

---apagar registro na tabela
delete from usuario where login = 'teste'

select login,cep from usuario 

--------segunda tabela--------
create table depentende (id int identity(1,1),
nome varchar(100),
dt_nascimento datetime,
id_pai int)

insert into depentende values('Heitor',getdate(),3)

-----------select em v�rias tabelas------------

select * from usuario 
inner join depentende on usuario.id = depentende.id_pai


select * from usuario u
left join depentende d on u.id = d.id_pai
where login ='eneves' 
